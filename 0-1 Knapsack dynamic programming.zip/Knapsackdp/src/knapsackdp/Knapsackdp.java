 
package knapsackdp;
 
public class Knapsackdp {

    
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        int value[]={10,40,30,1};
        int weight[]={5,4,6,3};
        int W= 10;
        
       System.out.println(knapsack(value,weight,W));
    }
    
    public static int knapsack(int value[],int weight[],int W){
        
       int B= weight.length;
       int [][] PP = new int [B+1][W+1];
       for (int col=0; col<=W; col++){
           
           PP[0][col]=0;
       }
       
       for (int row=0; row<=B; row++){
           
           PP[row][0]=0;
        
    }
       for (int item=1;item<=B;item++){
           for (int wgt=1;wgt<=W;wgt++){
                if (weight[item-1]<=wgt){
                    
                     PP[item][wgt]=Math.max(value[item-1]+PP[item-1 ][wgt-weight[item-1]],PP[item-1][wgt])
                }
                else{
                    PP[item][wgt]=PP[item-1][wgt];
                }
           }
       }
               for (int[] rows : PP) {

            for (int col : rows) {

                System.out.format("%5d", col);

            }

            System.out.println();

        }

        return PP[B][W];

    }

}
       
        
    
 
